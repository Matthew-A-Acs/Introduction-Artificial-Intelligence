## ********************************************************************** ##
## Created by Matthew Acs (z23536012) and Richard Acs (z23536011)         ##
## Assignment 1, Search Strategies, Due 6/11/2021                         ##
## ********************************************************************** ##

from collections import deque
import copy

## defines constants that will be used in the minmax algorithm
MIN = -1
MAX = 1

## class that defines a move in the tic tac toe game.
## Each move has an associated move number and score
class Move:
    def __init__(self, move=0, score=0):
        self.move = move
        self.score = score
## class for the tic tac toe board. The class contains an array that represents
## the spaces and the moves that were made on the board. The methods in the class
## allow moves to be played, the score to be obtained, possible moves to be 
## obtained, to check for a tie, and to display the contents of the board
class Board:
    ## constructor that initializes the array to contain numbers 1-9
    ## and for the turn to be x
    def __init__(self):
        self.data = [1,2,3,4,5,6,7,8,9]
        self.turn = "x"
    
    ## the method returns the score based on possible endstates
    ## -10 represents a win for x while 10 represents a win for o.
    ## 0 represents a tie or a game in progress
    def get_score(self):
        if self.data[0] == self.data[1] == self.data[2] == "x":
          return -10
        elif self.data[3] == self.data[4] == self.data[5] == "x":
          return -10
        elif self.data[6] == self.data[7] == self.data[8] == "x":
          return -10
        elif self.data[0] == self.data[3] == self.data[6] == "x":
          return -10
        elif self.data[1] == self.data[4] == self.data[7] == "x":
          return -10
        elif self.data[2] == self.data[5] == self.data[8] == "x":
          return -10
        elif self.data[0] == self.data[4] == self.data[8] == "x":
          return -10
        elif self.data[2] == self.data[4] == self.data[6] == "x":
          return -10
        elif self.data[0] == self.data[1] == self.data[2] == "o":
          return 10
        elif self.data[3] == self.data[4] == self.data[5] == "o":
          return 10
        elif self.data[6] == self.data[7] == self.data[8] == "o":
          return 10
        elif self.data[0] == self.data[3] == self.data[6] == "o":
          return 10
        elif self.data[1] == self.data[4] == self.data[7] == "o":
          return 10
        elif self.data[2] == self.data[5] == self.data[8] == "o":
          return 10
        elif self.data[0] == self.data[4] == self.data[8] == "o":
          return 10
        elif self.data[2] == self.data[4] == self.data[6] == "o":
          return 10
        else:
          return 0
    
    ## the method checks if the board contains a tie and returns 1 if it does
    ## else it returns 0
    def isfull(self):
        for z in range(9):
            if ((self.data[z] != "x") and (self.data[z] != "o")):
                return 0
        return 1
    
    ## the method executes a move by replacing the corresponding array index
    ## with an x or o. The turn is then changed.
    def execute(self, move):
        self.data[move-1] = self.turn
        if self.turn == "x":
            self.turn = "o"
        else:
            self.turn = "x"
    
    ## the method returns an array of possible moves by checking if the array
    ## indexes contain digits or x/o
    def get_moves(self):
        moves = []
        for z in range(9):
          if ((self.data[z] != "x") and (self.data[z] != "o")):
            moves.append(self.data[z])
        return moves
    
    ## the method displays the board without the digits by making a copy
    ## of the current board, removing the digits, and printing the contents
    def display(self):
        sim = copy.deepcopy(self)
        for z in range(9):
          if ((self.data[z] != "x") and (self.data[z] != "o")):
            sim.data[z] = " "
        print(sim.data[0], sim.data[1], sim.data[2], sep=" | ")
        print("----------")
        print(sim.data[3], sim.data[4], sim.data[5], sep=" | ")
        print("----------")
        print(sim.data[6], sim.data[7], sim.data[8], sep=" | ", end='\n\n')
    
    ## the method displays the board with the digits for the user to
    ## see which numbers correspond to which spaces
    def display_first(self):
        print("1","2","3", sep=" | ")
        print("----------")
        print("4","5","6", sep=" | ")
        print("----------")
        print("7","8","9", sep=" | ", end='\n\n')

## The function takes the specified arguments and returns the best possible move
## that the agent could make. The minmax algorithm uses alpha beta pruning to reduce
## computation time.
def minmax(state, depth, min_or_max, last_move, alpha, beta):
    
    ## obtains the current score
    current_score = state.get_score()
    
    ## conditions for the recursion to terminate
    if ((current_score !=0) or (state.isfull()) or (depth == 0)):
        return Move(last_move, current_score)

    best_score = min_or_max * -999
    best_move = -1
    choices = state.get_moves()
    
    ## iterates through all possible moves that could be made
    for move in choices:
        neighbor = copy.deepcopy(state)
        neighbor.execute(move)
        
        ## recursive call to minmax
        best_neighbor = minmax(neighbor, depth-1, min_or_max*-1, move, alpha, beta)
        
        ## if the move has a better score/worse score and is set to max/min, the best move and score and updated
        if ( ((best_neighbor.score > best_score) and (min_or_max == MAX)) or ((best_neighbor.score < best_score) and (min_or_max == MIN)) ):
            best_score = best_neighbor.score
            best_move = move
            if (best_score >= alpha) and (min_or_max == MAX):
                alpha = best_score ##updates alpha for use in alpha beta pruning
            if (best_score <= beta) and (min_or_max == MIN):
                beta = best_score  ##updates beta for use in alpha beta pruning
        if alpha>=beta:
            break   ##allows algorithm to not explore parts of gametree that would not impact min/max decision
    
    ## the best move and score is eventually returned after all recursion terminates
    return Move(best_move, best_score)

## the function uses the previous classes, functions, and methods to make a playable]
## tic tac toe game with user input, input validation, and an interface. The function
## is recursive and therefore takes a boolean argument to indicate if it is being called
## for the first time or not
def play_tic_tac_toe(first):
    
    ## creates an instance of the board class
    game = Board()
    
    ## displays a message about the game to the user
    if(first):
        print("This application allows you to play tic tac toe against a perfect AI opponent.")
        print("The AI is unbeatable thanks to its minmax algorithm implementation, but you can still try...", end='\n\n')
        print("-------------------------------")
        print("TIC-TAC-TOE")
        print("Play tic tac toe against an AI!")
        print("-------------------------------", end='\n\n')
    
    ## displays board with numbers to show users what the inputs correspond to
    game.display_first()
    
    ## gets and validates user input for which player they would like to play as
    player = input("Would you like to play as x or o? ")
    while (player != "o") and (player != "x"):
        player = input("Please enter valid input: ")
    
    ## while the game is not finished, get the moves from the user/ai, preform the moves,
    ## display the board, and check for a win/tie state
    while (game.get_score() == 0) and (not game.isfull()):
        if game.turn == player:
            
            ## gets and validates user input
            selection = input("Enter move (1-9): ")
            valid_moves = game.get_moves()
            invalid = 1
            while invalid:
                for x in valid_moves:
                    if selection == str(x):
                        invalid = 0
                if invalid:
                    selection = input("Please enter valid input: ")

            print("")
        else:
            
            ## gets the input from the tic tac toe AI using the minmax algorithm
            print("AI's Turn to Move", end='\n\n')
            if player == "x":
                m = MAX
            else:
                m = MIN
            selection = minmax(game, 10, m, 0, -999, 999).move
            
        ## executes the move and displays the board
        game.execute(int(selection))
        game.display()
        
        ## checks for a win/tie state and displays a message
        if game.get_score() == -10:
            print("-------")
            print('x Wins!')
            print("-------", end='\n\n')
        elif game.get_score() == 10:
            print("-------")
            print('o Wins!')
            print("-------", end='\n\n')
        elif game.isfull():
            print("-------")
            print("Tie")
            print("-------", end='\n\n')
    
    ## prompts the user if they would like to play again and executes the users request
    again = input("Would you like to play again (y or n)? ")
    if again == "y":
        print("")
        play(0)
        
## class to hold the map of Romania with assosiated
## distances between cities. The map is stored as a dictionary 
## attribute called graph with each city being represented by the 
## first letter in its name. The attribute straightline_cost is
## another dictionary that stores the straightline_cost of each city.
## finaly,the class contains a function, get_children, which returns
## an array of location objects that represent the possible moves from
## a specific city given the current location object
class rom_map:
    ##constructor
    def __init__(self):
        ##dictionary attribute to hold romania map and inter-city distances.
        ##odd indexes store the distances, even indexes store the cities. 
        self.graph = {"a" : ["z",75,"s",140,"t",118],
                 "b" : ["p",101,"u",85,"g",90,"f",211],
                 "c" : ["d",120,"r",146,"p",138],
                 "d" : ["m",75,"c",120],
                 "e" : ["h",86],
                 "f" : ["s",99,"b",211],
                 "g" : ["b",90],
                 "h" : ["e",86,"u",98],
                 "i" : ["v",92,"n",87],
                 "l" : ["m",70,"t",111],
                 "m" : ["l",70,"d",75],
                 "n" : ["i",87],
                 "o" : ["s",151,"z",71],
                 "p" : ["r",97,"b",101,"c",138],
                 "r" : ["s",80,"p",97,"c",146],
                 "s" : ["f",99,"o",151,"a",140,"r",80],
                 "t" : ["a",118,"l",111],
                 "u" : ["h",98,"v",142,"b",85],
                 "v" : ["i",92,"u",142],
                 "z" : ["o",71,"a",75]
                 }
        
        ##dictionary attribute to hold the straightline_cost of each city.
        self.straightline_cost = {"a" : 366,
                 "b" : 0,
                 "c" : 160,
                 "d" : 242,
                 "e" : 161,
                 "f" : 178,
                 "g" : 77,
                 "h" : 151,
                 "i" : 226,
                 "l" : 244,
                 "m" : 241,
                 "n" : 234,
                 "o" : 380,
                 "p" : 98,
                 "r" : 193,
                 "s" : 253,
                 "t" : 329,
                 "u" : 80,
                 "v" : 199,
                 "z" : 374
                 }
    
    ## returns an array of children locations (cities) given a 
    ## location object (current city).
    def get_children(self, current_point):
        Array = []
        ## finds current city in the stored map and appends connected cities
        ## to an arary after creating a location object for each city.
        for key in self.graph:
            if key == current_point.name: 
                for x in self.graph[key]:
                    if type(x) != int:
                        temp = location(x)
                        Array.append(temp)
        return Array ##returns array of location objects.

## Location class is used to store information about
## the current point/city on the romania map.
## Has attributes parent, cost, and name.
class location:
    def __init__(self, names = " "):
        self.parent = None ##stores parent of current city
        self.cost = None ##stores cost (for a* search)
        self.driving_distance = None ##stores driving distance from parent to current city
        self.name = names ##stores name of current city

## Location class is used to store information about
## the path from the starting city to Bucharest.
class final_path:
    def __init__(self):
        self.path = deque() ##stores strings with information about cities in route
        self.distance = 0 ## stores total driving distance required 

##Given an array of visited cities, and the name of a city in question,
##the function returns true if the city has been visited.
def is_visited(visited, name):
    for x in visited:
        if name == x.name:
            return True

##Given a location object returned from the search funcitons and 
##the rom_map object, the function traces the best route of travel
##from the starting city used for the search functions using the parents
##of the function object. Returns a final_path object.
def get_path(child1, romania):
    child = copy.deepcopy(child1)
    route = final_path()
    ##Traces route through the parents of the location object
    if child.parent != None:
        while child.parent != None:
            valid = 0
            for key in romania.graph:
                if key == child.name:
                    for x in romania.graph[key]:
                        if valid == 1:
                            child.driving_distance = x
                            valid = 0
                        if x == child.parent.name:
                            valid = 1
            y = convert_name(child.parent.name) + " --- " + str(child.driving_distance) + " km ---> " + convert_name(child.name)
            ##stores route data in the form "(city name) --- (distance) km ---> (city name)" for each
            ##stop city along the route
            route.path.appendleft(y)
            route.distance = route.distance + child.driving_distance
            child = child.parent
    return route

##Given a final_path object, the function prints the travel route/itinerary
def print_path(route):
    if len(route.path) == 0:
        print("Your already there!")
    for x in route.path:
        print(x) ##prints itinerary
    print('Total distance = ' + str(route.distance) + ' km') ##prints total distance


##Given a location object, the function returns the total travel distance
##from the starting city used for the search functions using the parents
##of the function object.    
def get_driving_distance(child1, romania): 
    child = copy.deepcopy(child1)
    distance = 0
    if child.parent == None:
        return 0
    ##Traces distance through the parents of the location object
    while child.parent != None:
        valid = 0
        for key in romania.graph:
            if key == child.name:
                for x in romania.graph[key]:
                    if valid == 1:
                        cost = x
                        valid = 0
                    if x == child.parent.name:
                        valid = 1
        distance = cost + distance
        child = child.parent
    return distance
    
##Given the first letter (lowercase) of a city's name,
##the function returns the full name of the city.
def convert_name(name):
    if name == "a":
        return "Arad"
    elif name == "b":
        return "Bucharest"
    elif name == "c":
        return "Craiova"
    elif name == "d":
        return "Dobreta"
    elif name == "e":
        return "Eforie"
    elif name == "f":
        return "Fagaras"
    elif name == "g":
        return "Giurgiu"
    elif name == "h":
        return "Hirsova"
    elif name == "i":
        return "Iasi"
    elif name == "l":
        return "Lugoj"
    elif name == "m":
        return "Mehadia"
    elif name == "n":
        return "Neamt"
    elif name == "o":
        return "Oradea"
    elif name == "p":
        return "Pitesti"
    elif name == "r":
        return "Rimnicu Vilcea"
    elif name == "s":
        return "Sibiu"
    elif name == "t":
        return "Timisoara"
    elif name == "u":
        return "Urziceni"
    elif name == "v":
        return "Vaslui"
    elif name == "z":
        return "Zerind"
    else:
        return "None"

##function returns a location object with links to parent objects
##that can be used to trace a good route to travel from a 
##start point to Bucharest, given a (starting) locaiton object
##and a rom_map object. Function uses a breadth first search traversal.
def run_bfs(romania, current_point):
    visited = []
    if current_point.name == "b":
        return current_point ##returns if starting from Bucharest
    queue = deque() ##queue used for storing/visiting cities 'breadth first'
    queue.append(current_point)
    visited.append(current_point)
    while queue:
        current_point = queue.popleft()
        children = romania.get_children(current_point)
        for child in children:
            if not is_visited(visited, child.name):
                child.parent = current_point
                queue.append(child)
                visited.append(child) ##visit/append nodes in a breadth first manner
                if child.name == "b":
                    return child
    return "no path found"

##function returns a location object with links to parent objects
##that can be used to trace an good route to travel from a 
##start point to Bucharest, given a (starting) locaiton object
##and a rom_map object. Function uses a depth first search traversal.
def run_dfs(romania, current_point):
    visited = []
    if current_point.name == "b": ##returns if starting from Bucharest
        return current_point
    stack = deque() ##stack used for storing/visiting cities 'depth first'
    stack.appendleft(current_point)
    while stack:
        current_point = stack.popleft()
        if not is_visited(visited, current_point.name):
            visited.append(current_point)
            if current_point.name == "b":
                return current_point
            else:
                children = romania.get_children(current_point)
                for child in children:
                    child.parent = current_point
                    stack.appendleft(child) ##visit/append nodes in a depth first manner
    return "No path to goal"

##function returns a location object with links to parent objects
##that can be used to trace a optimal route to travel from a 
##start point to Bucharest, given a (starting) locaiton object
##and a rom_map object. Function uses a* search traversal, with 
##the straightline distance of each city to Bucharest as the heuristic.
def run_astar(romania, current_point):
    visited = []
    if current_point.name == "b": ##returns if starting from Bucharest
        return current_point
    stack = deque()
    stack.appendleft(current_point)
    while stack:
        current_point = stack.popleft()
        if not is_visited(visited, current_point.name):
            visited.append(current_point)
            if current_point.name == "b":
                return current_point
            else:
                children = romania.get_children(current_point)
                for child in children:
                    child.parent = current_point
                    ##uses cost attribute of location object to store the heuristic
                    ##plus the total distance traveled from the start city to the current city
                    ##in qustion
                    child.cost = romania.straightline_cost[child.name] 
                    child.cost = child.cost + get_driving_distance(child, romania)
                    stack.appendleft(child)
                stack = deque(sorted(stack, key = lambda s: s.cost)) ##sorts stack by ascending cost
    return "No path to goal"

##function serves as an interface for the user to calculate their travel route
##from a starting city in romania to Bucharest.
def run_romania_gps():
    ##displays message explaining how to use program
    print("------------------------------------")
    print("ROAD-THROUGH-ROMANIA GPS")
    print("A gps that will take you to Bucharest from a city of your choice.")
    print("The gps uses a search algorithm to attempt to find the shortest path.")
    print("The gps is implemented using BFS, DFS, and A* search algorithms, and")
    print("you may choose which algorithm you want to use for each route calculation.")
    print("------------------------------------", end='\n\n')
    print("Possible Starting Locations (use lowercase first letter for input):")
    print("------------------------------------")
    print("Arad (a) Bucharest (b) Craiova (c) Dobreta (d)")
    print("Eforie (e) Fagaras (f) Giurgiu (g) Hirsova (h)")
    print("Iasi (i) Lugoj (l) Mehadia (m) Neamt (n)")
    print("Oradea (o) Pitesti (p) Rimnicu Vaslui (r) Sibiu (s)")
    print("Timisoara (t) Urziceni (u) Vaslui (v) Zerind (z)", end='\n\n')
    
    again = "y"
    
    ##checks to see if use wants to calculate another route
    while again == "y": 
        Romania = rom_map()
        start_loc = input("Enter your starting location: ")
        ##validates input
        while (start_loc != "a") and (start_loc != "b") and (start_loc != "c") and (start_loc != "d") and (start_loc != "e") and (start_loc != "f") and (start_loc != "g") and (start_loc != "h") and (start_loc != "i") and (start_loc != "l") and (start_loc != "m") and (start_loc != "n") and (start_loc != "o") and (start_loc != "p") and (start_loc != "r") and (start_loc != "s") and (start_loc != "t") and (start_loc != "u") and (start_loc != "v") and (start_loc != "z"):
            start_loc = input("Please enter valid input: ")
        locationa = location(start_loc)
        algorithm = input("Enter your algorithm selection, bfs (b), dfs (d), or a* (a): ")
        ##validates input
        while (algorithm != "a") and (algorithm != "b") and (algorithm != "d"):
            algorithm = input("Please enter valid input: ")
        print()
        print("Itinerary:")
        print("-------------")
        ##runs chosen algorithm
        if algorithm == "b":
            path = run_bfs(Romania, locationa)
        elif algorithm == "d":
            path = run_dfs(Romania, locationa)
        elif algorithm == "a":
            path = run_astar(Romania, locationa)
        final_route = get_path(path, Romania)
        ##displays route
        print_path(final_route)
        print("-------------", end='\n\n')
        again = input("Would you like to calculate another route? (y or n): ")

## driver to run the programs
y = "y"
while y == "y":
    x = input("Would you like to run the Romania GPS or Tic Tac Toe (1 or 2)?: ")
    while (x != "1") and (x != "2"):
        x = input("Please enter a valid input: ")
    if x == "1":
        run_romania_gps()
    elif x == "2":
        play_tic_tac_toe(1)
    y = input("Would you like to run another program (y or n)?: ")
